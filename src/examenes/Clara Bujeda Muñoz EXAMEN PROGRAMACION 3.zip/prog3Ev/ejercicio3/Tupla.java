package examenes.prog3Ev.ejercicio3;

public class Tupla {
	
	private Node node;
	private int index;
	
	public Tupla(Node node, int index) {
		super();
		this.node = node;
		this.index = index;
	}
	
	public Tupla() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Node getNode() {
		return node;
	}
	
	public void setNode(Node node) {
		this.node = node;
	}
	
	public int getIndex() {
		return index;
	}
	
	public void setIndex(int index) {
		this.index = index;
	}
	
	

}
